# Watch8 原生售价计算器

适用于 Galaxy Watch8 的原生 Canvas 计算器，无 WebView。

底部四键：AC ｜ = ｜ 填入批发价 ｜ 退格。

计算公式：最终售价 = 批发价 × (1 + 税率/100) × (1 + 利润率/100)。

本源码 ZIP 作为 GitHub Actions 的输入上传到仓库根目录，不需要手动解压。
创建 `.github/workflows/build.yml` 后，提交该文件就会自动开始构建；也可通过 Run workflow 手动构建。
